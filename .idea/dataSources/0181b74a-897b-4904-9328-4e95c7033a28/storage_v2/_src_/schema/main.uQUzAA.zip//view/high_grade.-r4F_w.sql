CREATE VIEW high_grade AS
        SELECT MAX(grade) AS highest_grade
        FROM grades;

