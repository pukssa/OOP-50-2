CREATE VIEW get_alfa AS
        SELECT name, age
        FROM users
        WHERE age <= 15;

